# dispatcher.py
#
# Changes vs original:
#   1. WASTE HEAT AS HP SOURCE — during shift hours, T_WASTE_HEAT (70 °C)
#      is passed to hp_model as the source temperature instead of ambient.
#      This reflects the physical configuration shown in the project diagram,
#      where waste heat at 70 °C feeds the HP as the low-side heat source.
#      Effect: higher source T → smaller temperature lift → higher COP.
#   2. VARIABLE COP — hp_model.simulate() now receives T_source_C and
#      T_sink_C instead of a fixed COP scalar.
#   3. SOLAR FRACTION KPI — computed and included in participation dict.
#      SF = (Q_solar_direct + Q_tes) / Q_demand  (purely solar sources).

import numpy as np
import params as P
import stc_model
import tes_model
import hp_model
import el_heater_model
import pv_model
import bess_model


def _safe_share(arr, demand):
    total = demand.sum()
    return float(arr.sum() / total) if total > 0 else 0.0


def run(climate, Q_demand_W, n_stc, E_tes_Wh, n_pv, E_bess_Wh):
    """
    Run the full dispatch chain for one candidate design.

    Dispatch order (thermal side):
        STC direct → TES discharge → Heat pump → Electric heater

    Electrical side:
        PV → BESS → Grid (covers HP + EH electrical demand)

    Parameters
    ----------
    climate    : dict — from climate_data.load_climate_data()
    Q_demand_W : np.ndarray [W] — hourly process thermal demand
    n_stc      : int   — number of STC modules
    E_tes_Wh   : float — TES capacity [Wh]
    n_pv       : int   — number of PV modules
    E_bess_Wh  : float — BESS capacity [Wh]

    Returns
    -------
    dict — all hourly power flows, KPIs, and sizing metadata.
    """
    T_amb = climate['T_amb']

    # ── 1. Solar Thermal Collectors ───────────────────────────────────────
    stc_res        = stc_model.simulate(climate, n_stc)
    Q_solar        = stc_res['Q_solar_W']
    Q_solar_direct = np.minimum(Q_solar, Q_demand_W)
    Q_solar_surplus= np.maximum(Q_solar - Q_demand_W, 0.0)

    # ── 2. Thermal Energy Storage + waste heat charging ───────────────────
    in_shift  = ((climate['hour_of_day'] >= P.HOUR_START) &
                 (climate['hour_of_day'] <  P.HOUR_END))
    Q_waste_W = np.where(in_shift, P.Q_WASTE_MAX_W, 0.0)

    tes_res   = tes_model.simulate(Q_solar, Q_demand_W, E_tes_Wh,
                                   Q_waste_W=Q_waste_W)
    Q_tes     = tes_res['Q_tes_W']
    Q_after_tes = tes_res['Q_residual']

    # ── 3. Heat pump — waste heat used as source during shift hours ───────
    #
    # Physical rationale:
    #   The project diagram shows waste heat at 70 °C flowing into the HP
    #   as its low-side source.  During shift hours the waste stream is
    #   available (same hours as production), so the HP can use it instead
    #   of cold ambient air.  This raises the source temperature from
    #   ~15–25 °C (ambient) to 70 °C, dramatically reducing the temperature
    #   lift and improving COP.
    #
    #   Outside shift hours no waste heat is available and the HP falls back
    #   to ambient air as its source.
    T_hp_source = np.where(
        in_shift & (Q_waste_W > 0),
        P.T_WASTE_HEAT,    # 70 °C — waste heat source
        T_amb              # ambient air fallback
    )

    hp_res    = hp_model.simulate(Q_after_tes,
                                  T_source_C=T_hp_source,
                                  T_sink_C=P.T_SUPPLY)
    Q_hp      = hp_res['Q_hp_W']
    P_hp_elec = hp_res['P_hp_elec_W']
    COP_hourly= hp_res['COP_hourly']

    # ── 4. Electric heater — covers any remaining residual ────────────────
    el_res        = el_heater_model.simulate(hp_res['Q_residual_W'])
    Q_elheater    = el_res['Q_elheater_W']
    P_elheater_elec = el_res['P_elheater_elec_W']
    Q_unmet       = el_res['Q_residual_W']

    # ── 5. PV + BESS — cover electrical demand of HP + EH ─────────────────
    pv_res        = pv_model.simulate(climate, n_pv)
    P_elec_demand = P_hp_elec + P_elheater_elec
    bess_res      = bess_model.simulate(pv_res['P_pv_ac_W'], P_elec_demand,
                                        E_bess_Wh)

    # Allocate local (PV + BESS) electricity: HP first, then EH
    P_local              = bess_res['P_elec_from_local_W']
    P_hp_from_local      = np.minimum(P_local, P_hp_elec)
    remaining_local      = np.maximum(P_local - P_hp_from_local, 0.0)
    P_elheater_from_local= np.minimum(remaining_local, P_elheater_elec)
    P_hp_from_grid       = np.maximum(P_hp_elec      - P_hp_from_local,       0.0)
    P_elheater_from_grid = np.maximum(P_elheater_elec - P_elheater_from_local, 0.0)

    # ── 6. Aggregate thermal output ───────────────────────────────────────
    Q_covered = np.minimum(Q_solar_direct + Q_tes + Q_hp + Q_elheater,
                           Q_demand_W)

    # ── 7. KPIs ───────────────────────────────────────────────────────────
    E_demand = Q_demand_W.sum()

    # Solar Fraction — only purely-solar sources count
    # (STC direct + TES discharge originating from solar surplus)
    solar_fraction = (
        float((Q_solar_direct + Q_tes).sum() / E_demand)
        if E_demand > 0 else 0.0
    )

    # Weighted average COP (weighted by HP output)
    total_Q_hp = Q_hp.sum()
    cop_weighted_avg = (
        float((COP_hourly * Q_hp).sum() / total_Q_hp)
        if total_Q_hp > 0 else 0.0
    )

    pv_elec_sum  = float(P_hp_from_local.sum() + P_elheater_from_local.sum())
    bess_dis_sum = float(bess_res['P_bess_discharge_W'].sum())
    elec_dem_sum = float(P_elec_demand.sum())

    participation = {
        'stc_share':       _safe_share(Q_solar_direct, Q_demand_W),
        'tes_share':       _safe_share(Q_tes,          Q_demand_W),
        'hp_share':        _safe_share(Q_hp,           Q_demand_W),
        'elh_share':       _safe_share(Q_elheater,     Q_demand_W),
        'pv_elec_share':   pv_elec_sum  / elec_dem_sum if elec_dem_sum > 0 else 0.0,
        'bess_elec_share': bess_dis_sum / elec_dem_sum if elec_dem_sum > 0 else 0.0,
        'solar_fraction':  solar_fraction,
        'cop_weighted':    cop_weighted_avg,
        'hp_enabled':      hp_res['hp_enabled'],
    }

    return {
        # Thermal flows
        'Q_solar_W':           Q_solar,
        'Q_solar_direct_W':    Q_solar_direct,
        'Q_solar_surplus_W':   Q_solar_surplus,
        'Q_tes_W':             Q_tes,
        'Q_hp_W':              Q_hp,
        'Q_elheater_W':        Q_elheater,
        'Q_covered_W':         Q_covered,
        'Q_unmet_W':           Q_unmet,
        'Q_waste_charged_W':   tes_res['Q_waste_charged_W'],
        # TES state
        'SOC_TES':             tes_res['SOC'],
        'T_TES':               tes_res['T_tes'],
        # HP details
        'COP_hourly':          COP_hourly,
        'T_hp_source':         T_hp_source,
        # Electrical flows
        'P_hp_elec_W':            P_hp_elec,
        'P_elheater_elec_W':      P_elheater_elec,
        'P_hp_from_local_W':      P_hp_from_local,
        'P_elheater_from_local_W':P_elheater_from_local,
        'P_hp_from_grid_W':       P_hp_from_grid,
        'P_elheater_from_grid_W': P_elheater_from_grid,
        'P_pv_ac_W':           pv_res['P_pv_ac_W'],
        'P_pv_dc_W':           pv_res['P_pv_dc_W'],
        'P_bess_charge_W':     bess_res['P_bess_charge_W'],
        'P_bess_discharge_W':  bess_res['P_bess_discharge_W'],
        'SOC_BESS':            bess_res['SOC_BESS'],
        'P_grid_import_W':     bess_res['P_grid_import_W'],
        'P_grid_export_W':     bess_res['P_grid_export_W'],
        # Sizing metadata
        'n_stc':           n_stc,
        'E_tes_Wh':        E_tes_Wh,
        'n_pv':            n_pv,
        'E_bess_Wh':       E_bess_Wh,
        'A_stc_m2':        stc_res['A_total'],
        'A_pv_m2':         pv_res['A_pv_m2'],
        'P_pv_rated_kW':   pv_res['P_pv_rated_kW'],
        'V_tes_m3':        tes_res['V_tank_m3'],
        'eta_solar':       stc_res['eta'],
        'participation':   participation,
    }
