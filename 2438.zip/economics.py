# economics.py
#
# Changes vs original:
#   1. SOLAR FRACTION — separately computed from thermal coverage.
#   2. CO₂ EMISSIONS — grid import emissions and CO₂ avoided vs gas boiler.
#   3. NPV / IRR / PAYBACK — full financial assessment vs gas reference.
#   4. WEIGHTED COP — energy-weighted average HP COP over the year.
#   5. print_summary() — comprehensive structured KPI table.

import numpy as np
import params as P


# ─────────────────────────────────────────────────────────────────────────────
# Capital Recovery Factor
# ─────────────────────────────────────────────────────────────────────────────

def capital_recovery_factor(r=None, n=None):
    r = P.DISCOUNT_RATE if r is None else r
    n = P.LIFETIME_YR   if n is None else n
    return r * (1 + r) ** n / ((1 + r) ** n - 1)


CRF = capital_recovery_factor()


# ─────────────────────────────────────────────────────────────────────────────
# IRR — bisection solver
# ─────────────────────────────────────────────────────────────────────────────

def _irr(cash_flows, max_iter=2000, tol=1e-7):
    """
    Internal Rate of Return via bisection.

    cash_flows : list — [CF_0, CF_1, ..., CF_N]
                 CF_0 is typically −CAPEX (negative).
    Returns NaN if no real IRR exists in (−99 %, 5000 %).
    """
    def npv_at(r):
        return sum(cf / (1.0 + r) ** t for t, cf in enumerate(cash_flows))

    lo, hi = -0.999, 50.0
    f_lo, f_hi = npv_at(lo), npv_at(hi)
    if f_lo * f_hi > 0:
        return float('nan')

    for _ in range(max_iter):
        mid = (lo + hi) / 2.0
        f_mid = npv_at(mid)
        if abs(f_mid) < tol or (hi - lo) < tol:
            return mid
        if f_lo * f_mid < 0:
            hi, f_hi = mid, f_mid
        else:
            lo, f_lo = mid, f_mid
    return (lo + hi) / 2.0


# ─────────────────────────────────────────────────────────────────────────────
# Main economics computation
# ─────────────────────────────────────────────────────────────────────────────

def compute(dispatch_result, Q_demand_W):
    """
    Compute all techno-economic KPIs for one dispatch result.

    Returns a dict containing energy flows, costs, LCOH, solar fraction,
    CO₂ emissions/avoidance, NPV, IRR, and payback period.
    """
    A_stc      = dispatch_result['A_stc_m2']
    E_tes_Wh   = dispatch_result['E_tes_Wh']
    P_hp_kW    = P.HP_CAPACITY_KW
    P_el_kW    = P.EL_HEATER_CAPACITY_KW
    P_pv_kWp   = dispatch_result['P_pv_rated_kW']
    E_bess_kWh = dispatch_result['E_bess_Wh'] / 1000.0
    P_inv_kW   = dispatch_result['P_pv_rated_kW']

    # ── CAPEX ────────────────────────────────────────────────────────────
    capex_stc      = A_stc        * P.CAPEX_STC_PER_M2
    capex_tes      = (E_tes_Wh / 1000.0) * P.CAPEX_TES_PER_KWH
    capex_hp       = P_hp_kW      * P.CAPEX_HP_PER_KW
    capex_elheater = P_el_kW      * P.CAPEX_EL_HEATER_KW
    capex_pv       = P_pv_kWp     * P.CAPEX_PV_PER_KWP
    capex_bess     = E_bess_kWh   * P.CAPEX_BESS_PER_KWH
    capex_inv      = P_inv_kW     * P.CAPEX_INV_PER_KW
    capex_total    = (capex_stc + capex_tes + capex_hp + capex_elheater
                      + capex_pv + capex_bess + capex_inv)

    # ── O&M ─────────────────────────────────────────────────────────────
    om_annual = (
        capex_stc      * P.OM_STC_FRAC  +
        capex_tes      * P.OM_TES_FRAC  +
        capex_hp       * P.OM_HP_FRAC   +
        capex_elheater * P.OM_EL_FRAC   +
        capex_pv       * P.OM_PV_FRAC   +
        capex_bess     * P.OM_BESS_FRAC +
        capex_inv      * P.OM_INV_FRAC
    )

    # ── Electricity costs / revenues ─────────────────────────────────────
    grid_import_kWh       = dispatch_result['P_grid_import_W'].sum() / 1000.0
    grid_export_kWh       = dispatch_result['P_grid_export_W'].sum() / 1000.0
    elec_cost_annual      = grid_import_kWh * P.ELEC_PRICE
    export_revenue_annual = grid_export_kWh * P.ELEC_EXPORT_PRICE

    # ── Annualised total system cost ─────────────────────────────────────
    annual_capex_cost  = capex_total * CRF
    annual_total_cost  = (annual_capex_cost + om_annual
                          + elec_cost_annual - export_revenue_annual)

    # ── Thermal energy summary [MWh/yr] ──────────────────────────────────
    E_demand  = Q_demand_W.sum()                              / 1e6
    E_solar   = dispatch_result['Q_solar_direct_W'].sum()     / 1e6
    E_tes     = dispatch_result['Q_tes_W'].sum()              / 1e6
    E_hp      = dispatch_result['Q_hp_W'].sum()               / 1e6
    E_el      = dispatch_result['Q_elheater_W'].sum()         / 1e6
    E_covered = dispatch_result['Q_covered_W'].sum()          / 1e6
    E_unmet   = dispatch_result['Q_unmet_W'].sum()            / 1e6

    # ── LCOH [€/MWh_th] ──────────────────────────────────────────────────
    lcoh = annual_total_cost / E_covered if E_covered > 0 else float('inf')

    # ── Solar Fraction [%] ────────────────────────────────────────────────
    # Only purely solar contributions: STC direct + TES discharge.
    # The HP and electric heater are NOT solar even if powered by PV,
    # because they convert electricity to heat (chain breaks).
    solar_fraction_pct = (
        (E_solar + E_tes) / E_demand * 100.0 if E_demand > 0 else 0.0
    )

    # ── CO₂ emissions ────────────────────────────────────────────────────
    # Actual: CO₂ from grid electricity imported by the system
    co2_grid_tonne_yr = grid_import_kWh * P.CO2_GRID_KG_KWH / 1000.0

    # Reference: meeting ALL thermal demand with a gas boiler
    gas_demand_kwh      = (E_demand * 1e3) / P.BOILER_EFFICIENCY  # kWh_gas
    co2_reference_kg    = gas_demand_kwh * P.CO2_GAS_KG_KWH
    co2_avoided_tonne_yr= (co2_reference_kg / 1000.0) - co2_grid_tonne_yr

    # ── Financial assessment vs gas boiler reference ──────────────────────
    gas_cost_annual = gas_demand_kwh * P.GAS_PRICE_EUR_KWH
    annual_saving   = gas_cost_annual - annual_total_cost

    # Cash-flow stream: year 0 = −CAPEX; years 1–N = net annual saving
    cash_flows = [-capex_total] + [annual_saving] * P.LIFETIME_YR
    npv        = sum(cf / (1.0 + P.DISCOUNT_RATE) ** t
                     for t, cf in enumerate(cash_flows))
    irr        = _irr(cash_flows)
    payback_yr = (capex_total / annual_saving
                  if annual_saving > 0 else float('inf'))

    # ── Weighted average COP ──────────────────────────────────────────────
    if 'COP_hourly' in dispatch_result:
        cop_arr   = dispatch_result['COP_hourly']
        q_hp_arr  = dispatch_result['Q_hp_W']
        total_qhp = q_hp_arr.sum()
        cop_weighted = (float((cop_arr * q_hp_arr).sum()) / total_qhp
                        if total_qhp > 0 else 0.0)
    else:
        cop_weighted = float('nan')

    return {
        # ── Energy flows ──────────────────────────────────────
        'E_demand_MWh':           E_demand,
        'E_solar_MWh':            E_solar,
        'E_tes_MWh':              E_tes,
        'E_hp_MWh':               E_hp,
        'E_elheater_MWh':         E_el,
        'E_covered_MWh':          E_covered,
        'E_unmet_MWh':            E_unmet,
        'thermal_share':          E_covered / E_demand * 100.0 if E_demand > 0 else 0.0,
        # ── Solar ────────────────────────────────────────────
        'solar_fraction':         solar_fraction_pct,
        # ── Cost breakdown ───────────────────────────────────
        'capex_total':            capex_total,
        'capex_stc':              capex_stc,
        'capex_tes':              capex_tes,
        'capex_hp':               capex_hp,
        'capex_elheater':         capex_elheater,
        'capex_pv':               capex_pv,
        'capex_bess':             capex_bess,
        'capex_inv':              capex_inv,
        'om_annual':              om_annual,
        'elec_cost_annual':       elec_cost_annual,
        'export_revenue_annual':  export_revenue_annual,
        'annual_capex_cost':      annual_capex_cost,
        'annual_total_cost':      annual_total_cost,
        # ── Main economic KPI ────────────────────────────────
        'LCOH':                   lcoh,
        'CRF':                    CRF,
        # ── Financial vs gas reference ───────────────────────
        'gas_cost_annual':        gas_cost_annual,
        'annual_saving':          annual_saving,
        'NPV':                    npv,
        'IRR':                    irr,
        'payback_yr':             payback_yr,
        # ── CO₂ ──────────────────────────────────────────────
        'co2_grid_tonne_yr':      co2_grid_tonne_yr,
        'co2_avoided_tonne_yr':   co2_avoided_tonne_yr,
        # ── HP ───────────────────────────────────────────────
        'COP_weighted':           cop_weighted,
    }


# ─────────────────────────────────────────────────────────────────────────────
# KPI print summary
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(econ, dispatch, label='OPTIMAL DESIGN'):
    """Print a structured KPI table to stdout."""

    W = 68
    sep  = "=" * W
    dash = "-" * W

    def row(label, value='', unit=''):
        print("  {:<38} {:>14}  {}".format(label, value, unit))

    def row_indent(label, value, unit=''):
        print("    {:<36} {:>14}  {}".format(label, value, unit))

    def section(title):
        print("\n  ── {} {}".format(title, "─" * (W - 6 - len(title))))

    print("\n" + sep)
    print("  KPI SUMMARY — {}".format(label))
    print(sep)

    # ── System sizing ────────────────────────────────────────────────────
    section("SYSTEM SIZING")
    row("STC modules",       "{:,}".format(dispatch['n_stc']),                   "modules")
    row("STC aperture area", "{:.0f}".format(dispatch['A_stc_m2']),              "m²")
    row("TES capacity",      "{:.1f}".format(dispatch['E_tes_Wh'] / 1e6),        "MWh_th")
    row("TES volume",        "{:.0f}".format(dispatch['V_tes_m3']),              "m³")
    row("HP capacity",       "{:.0f}".format(P.HP_CAPACITY_KW),                  "kW_th")
    row("HP enabled",        "Yes" if dispatch['participation']['hp_enabled'] else "No (T > T_max)", "")
    row("Electric heater",   "{:.0f}".format(P.EL_HEATER_CAPACITY_KW),           "kW_th")
    row("PV rated power",    "{:.0f}".format(dispatch['P_pv_rated_kW']),         "kWp")
    row("PV area",           "{:.0f}".format(dispatch['A_pv_m2']),               "m²")
    row("BESS capacity",     "{:.1f}".format(dispatch['E_bess_Wh'] / 1e6),       "MWh_el")

    # ── Thermal performance ──────────────────────────────────────────────
    section("THERMAL PERFORMANCE")
    row("Annual thermal demand",   "{:.1f}".format(econ['E_demand_MWh']),   "MWh_th/yr")
    row("Annual heat covered",     "{:.1f}".format(econ['E_covered_MWh']),  "MWh_th/yr")
    row("Unmet demand",            "{:.1f}".format(econ['E_unmet_MWh']),    "MWh_th/yr")
    row("Thermal coverage",        "{:.1f}".format(econ['thermal_share']),  "%")
    row("Solar Fraction (SF)",     "{:.1f}".format(econ['solar_fraction']), "%")
    row("HP weighted avg COP",     "{:.2f}".format(econ['COP_weighted']),   "-")
    print()
    row("Contributions:")
    row_indent("STC direct",         "{:.1f}".format(econ['E_solar_MWh']),    "MWh_th/yr")
    row_indent("TES discharge",      "{:.1f}".format(econ['E_tes_MWh']),      "MWh_th/yr")
    row_indent("Heat pump",          "{:.1f}".format(econ['E_hp_MWh']),       "MWh_th/yr")
    row_indent("Electric heater",    "{:.1f}".format(econ['E_elheater_MWh']), "MWh_th/yr")

    # ── Electrical performance ───────────────────────────────────────────
    section("ELECTRICAL PERFORMANCE")
    row("PV generation (AC)",  "{:.1f}".format(dispatch['P_pv_ac_W'].sum() / 1e6),         "MWh_el/yr")
    row("Grid import",         "{:.1f}".format(dispatch['P_grid_import_W'].sum() / 1e6),   "MWh_el/yr")
    row("Grid export",         "{:.1f}".format(dispatch['P_grid_export_W'].sum() / 1e6),   "MWh_el/yr")
    part = dispatch['participation']
    print()
    row("Subsystem shares (thermal demand):")
    row_indent("STC direct",        "{:.1f}".format(part['stc_share']  * 100), "%")
    row_indent("TES",               "{:.1f}".format(part['tes_share']  * 100), "%")
    row_indent("Heat pump",         "{:.1f}".format(part['hp_share']   * 100), "%")
    row_indent("Electric heater",   "{:.1f}".format(part['elh_share']  * 100), "%")
    row("Electrical supply shares (HP+EH load):")
    row_indent("PV direct",         "{:.1f}".format(part['pv_elec_share']   * 100), "%")
    row_indent("BESS discharge",    "{:.1f}".format(part['bess_elec_share'] * 100), "%")

    # ── CAPEX breakdown ──────────────────────────────────────────────────
    section("CAPEX BREAKDOWN")
    row("Total CAPEX",        "{:,.0f}".format(econ['capex_total']),    "€")
    row_indent("STC",         "{:,.0f}".format(econ['capex_stc']),      "€")
    row_indent("TES",         "{:,.0f}".format(econ['capex_tes']),      "€")
    row_indent("Heat pump",   "{:,.0f}".format(econ['capex_hp']),       "€")
    row_indent("El. heater",  "{:,.0f}".format(econ['capex_elheater']), "€")
    row_indent("PV",          "{:,.0f}".format(econ['capex_pv']),       "€")
    row_indent("BESS",        "{:,.0f}".format(econ['capex_bess']),     "€")
    row_indent("Inverter",    "{:,.0f}".format(econ['capex_inv']),      "€")

    # ── Annual costs ─────────────────────────────────────────────────────
    section("ANNUAL COSTS & REVENUES")
    row("Annualised CAPEX",    "{:,.0f}".format(econ['annual_capex_cost']),    "€/yr")
    row("O&M",                 "{:,.0f}".format(econ['om_annual']),            "€/yr")
    row("Electricity purchase","{:,.0f}".format(econ['elec_cost_annual']),     "€/yr")
    row("Export revenue",      "{:,.0f}".format(econ['export_revenue_annual']),"€/yr")
    row("Total system cost",   "{:,.0f}".format(econ['annual_total_cost']),    "€/yr")
    row("Gas reference cost",  "{:,.0f}".format(econ['gas_cost_annual']),      "€/yr")

    # ── Main economic KPIs ───────────────────────────────────────────────
    section("KEY ECONOMIC KPIs")
    row("LCOH",           "{:.2f}".format(econ['LCOH']),                      "€/MWh_th")
    row("NPV (vs gas)",   "{:,.0f}".format(econ['NPV']),                      "€")
    irr_str = "{:.1f} %".format(econ['IRR'] * 100) if not np.isnan(econ['IRR']) else "n/a"
    row("IRR",            irr_str,                                             "")
    pb = econ['payback_yr']
    pb_str = "{:.1f}".format(pb) if pb < 100 else "> 25"
    row("Simple payback", pb_str,                                              "yr")
    row("Annual saving",  "{:,.0f}".format(econ['annual_saving']),            "€/yr")

    # ── Environmental KPIs ───────────────────────────────────────────────
    section("ENVIRONMENTAL KPIs")
    row("CO₂ from grid import",   "{:.0f}".format(econ['co2_grid_tonne_yr']),    "t CO₂/yr")
    row("CO₂ avoided vs gas",     "{:.0f}".format(econ['co2_avoided_tonne_yr']), "t CO₂/yr")
    co2_int = econ['co2_grid_tonne_yr'] * 1000.0 / econ['E_covered_MWh'] if econ['E_covered_MWh'] > 0 else 0
    row("CO₂ intensity (covered)","{:.1f}".format(co2_int),                      "kg CO₂/MWh_th")

    print("\n" + sep + "\n")
