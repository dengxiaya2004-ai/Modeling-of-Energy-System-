# el_heater_model.py

import numpy as np
import params as P


def simulate(Q_residual_W, P_elheater_kW=None, efficiency=None):
    if P_elheater_kW is None:
        P_elheater_kW = P.EL_HEATER_CAPACITY_KW
    if efficiency is None:
        efficiency = P.EL_HEATER_EFF

    q_max = P_elheater_kW * 1000.0 * efficiency
    q_el = np.minimum(np.maximum(Q_residual_W, 0.0), q_max)
    p_el = q_el / efficiency
    q_after = np.maximum(Q_residual_W - q_el, 0.0)

    return {
        'Q_elheater_W': q_el,
        'P_elheater_elec_W': p_el,
        'Q_residual_W': q_after,
        'P_elheater_kW': P_elheater_kW,
        'efficiency': efficiency,
    }
