# bess_model.py

import numpy as np
import params as P


def simulate(P_supply_W, P_demand_W, E_bess_Wh):
    n = len(P_supply_W)
    soc = np.zeros(n)
    p_charge = np.zeros(n)
    p_discharge = np.zeros(n)
    p_to_load = np.zeros(n)
    p_export = np.zeros(n)
    p_grid_import = np.zeros(n)

    soc_now = P.BESS_SOC_INITIAL * E_bess_Wh
    e_min = P.BESS_SOC_MIN * E_bess_Wh
    e_max = P.BESS_SOC_MAX * E_bess_Wh
    p_max = P.BESS_MAX_C_RATE * E_bess_Wh

    for t in range(n):
        supply = max(0.0, P_supply_W[t])
        demand = max(0.0, P_demand_W[t])
        soc_now *= (1.0 - P.BESS_LOSS_FRAC)

        # Direct PV to load first
        p_direct = min(supply, demand)
        net = supply - p_direct
        remaining = demand - p_direct

        # Charge with surplus
        if net > 0 and E_bess_Wh > 0:
            room = max(e_max - soc_now, 0.0)
            p_ch = min(net, p_max, room / P.BESS_ETA_CHARGE)
            soc_now += p_ch * P.BESS_ETA_CHARGE
            p_charge[t] = p_ch
            net -= p_ch

        # Discharge if demand remains
        if remaining > 0 and E_bess_Wh > 0:
            available = max(soc_now - e_min, 0.0)
            p_dis = min(remaining, p_max, available * P.BESS_ETA_DISCHARGE)
            soc_now -= p_dis / P.BESS_ETA_DISCHARGE
            p_discharge[t] = p_dis
            remaining -= p_dis

        p_to_load[t] = p_direct + p_discharge[t]
        p_export[t] = max(net, 0.0)
        p_grid_import[t] = max(remaining, 0.0)
        soc[t] = soc_now / E_bess_Wh if E_bess_Wh > 0 else 0.0

    return {
        'P_bess_charge_W': p_charge,
        'P_bess_discharge_W': p_discharge,
        'P_elec_from_local_W': p_to_load,
        'P_grid_import_W': p_grid_import,
        'P_grid_export_W': p_export,
        'SOC_BESS': soc,
        'E_bess_Wh': E_bess_Wh,
    }
