Integrated whole-plant patch

Files added/updated:
- climate_data.py
- params.py
- pv_model.py
- bess_model.py
- hp_model.py
- el_heater_model.py
- dispatcher.py
- economics.py
- optimiser.py
- main.py

Key updates:
1) Integrated PV+BESS as electrical support for HP and electric heater.
2) Added HP and electric heater modules in project style.
3) Added participation constraints (scheme A) in optimiser.py.
4) Added timeline and monthly percentage plots in main.py.
5) Main now loads CSV relative to the script location.

Notes:
- This patch expects existing stc_model.py and tes_model.py from the team project.
- If no feasible design is found, relax MIN_*_SHARE values in params.py.
