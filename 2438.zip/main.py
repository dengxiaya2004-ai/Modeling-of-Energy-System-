# main.py

import os
import copy
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.sankey import Sankey

import climate_data
import economics
import optimiser
import sensitivity
import dispatcher
import params as P


def build_demand(climate):
    q = np.zeros(climate['n_hours'])
    for i in range(climate['n_hours']):
        h = climate['hour_of_day'][i]
        if P.HOUR_START <= h < P.HOUR_END:
            q[i] = P.LOAD_W
    return q


def _set_temperature(T_supply):
    T_return   = T_supply - 50.0
    P.T_SUPPLY  = T_supply
    P.T_RETURN  = T_return
    P.T_TES_MAX = T_supply + 5.0
    P.T_TES_MIN = max(T_return - 5.0, 30.0)
    P.DELTA_T_TES = P.T_TES_MAX - P.T_TES_MIN


def _restore_base_temperature():
    P.T_SUPPLY   = 100
    P.T_RETURN   = 50
    P.T_TES_MAX  = 105
    P.T_TES_MIN  = 55
    P.DELTA_T_TES = P.T_TES_MAX - P.T_TES_MIN


def run_temperature_scenarios(best_record, climate, Q_demand):
    n_stc    = best_record['n_stc']
    E_tes_Wh = best_record['E_tes_Wh']
    n_pv     = best_record['n_pv']
    E_bess_Wh= best_record['E_bess_Wh']

    scenario_results = {}
    base_T = P.T_SUPPLY

    for T in P.T_SUPPLY_SCENARIOS:
        _set_temperature(T)
        disp = dispatcher.run(climate, Q_demand, n_stc, E_tes_Wh, n_pv, E_bess_Wh)
        econ = economics.compute(disp, Q_demand)
        hp_ok = disp['participation']['hp_enabled']
        scenario_results[T] = {'dispatch': disp, 'econ': econ, 'hp_ok': hp_ok}
        print(
            "  T_supply = {0:3d} °C | LCOH = {1:7.2f} €/MWh_th | SF = {2:5.1f} % | COP_avg = {3:.2f} | HP = {4}".format(
                T, econ['LCOH'], econ['solar_fraction'], econ['COP_weighted'],
                "ON" if hp_ok else "DISABLED (T > {:.0f} °C)".format(P.HP_T_MAX)
            )
        )

    _set_temperature(base_T)
    return scenario_results


def _percent(arr, demand):
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.where(demand > 0, arr / demand * 100.0, 0.0)


def _safe_mwh(arr):
    return float(np.sum(arr) / 1e6)


def _typical_week_indices(climate, month):
    idx_month = np.where(climate['month'] == month)[0]
    if len(idx_month) >= 168:
        return idx_month[:168]
    return np.arange(min(168, climate['n_hours']))


def plot_typical_week_power(disp, Q_demand, climate):
    idx_week = _typical_week_indices(climate, P.PLOT_WEEK_MONTH)
    hrs = np.arange(len(idx_week))

    q_dem = Q_demand[idx_week] / 1e6
    q_stc = disp['Q_solar_direct_W'][idx_week] / 1e6
    q_tes = disp['Q_tes_W'][idx_week] / 1e6
    q_hp  = disp['Q_hp_W'][idx_week] / 1e6
    q_elh = disp['Q_elheater_W'][idx_week] / 1e6
    q_unm = disp['Q_unmet_W'][idx_week] / 1e6

    p_dem  = (disp['P_hp_elec_W'][idx_week] + disp['P_elheater_elec_W'][idx_week]) / 1e6
    p_pv   = np.maximum(
        disp['P_hp_from_local_W'][idx_week] + disp['P_elheater_from_local_W'][idx_week] - disp['P_bess_discharge_W'][idx_week],
        0.0
    ) / 1e6
    p_bess = disp['P_bess_discharge_W'][idx_week] / 1e6
    p_grid = disp['P_grid_import_W'][idx_week] / 1e6
    p_hp   = disp['P_hp_elec_W'][idx_week] / 1e6
    p_elh  = disp['P_elheater_elec_W'][idx_week] / 1e6

    fig, axes = plt.subplots(2, 1, figsize=(13, 8), sharex=True)

    ax = axes[0]
    ax.stackplot(hrs, q_stc, q_tes, q_hp, q_elh,
                 labels=['STC direct', 'TES discharge', 'Heat pump', 'El. heater'],
                 colors=['#F5A623', '#E07B54', '#4C72B0', '#55A868'])
    ax.plot(hrs, q_dem, color='black', linewidth=1.8, label='Thermal demand')
    if np.any(q_unm > 0):
        ax.plot(hrs, q_unm, color='#C44E52', linestyle='--', linewidth=1.5, label='Unmet')
    ax.set_ylabel('Thermal power  [MW_th]')
    ax.set_title(f'Typical week absolute dispatch (month {P.PLOT_WEEK_MONTH})')
    ax.grid(alpha=0.3)
    ax.legend(loc='upper right', ncol=3)

    ax = axes[1]
    ax.stackplot(hrs, p_pv, p_bess, p_grid,
                 labels=['PV direct', 'BESS discharge', 'Grid import'],
                 colors=['#F5A623', '#4C72B0', '#C44E52'])
    ax.plot(hrs, p_dem, color='black', linewidth=1.8, label='Electrical demand (HP + EH)')
    ax.plot(hrs, p_hp, color='#8172B2', linestyle='--', linewidth=1.2, label='HP electric load')
    ax.plot(hrs, p_elh, color='#64B5CD', linestyle='--', linewidth=1.2, label='EH electric load')
    ax.set_ylabel('Electrical power  [MW_el]')
    ax.set_xlabel('Hour of week')
    ax.grid(alpha=0.3)
    ax.legend(loc='upper right', ncol=3)

    plt.tight_layout()


def plot_source_sink_sankey(disp, Q_demand):
    e_demand = _safe_mwh(Q_demand)
    e_stc    = _safe_mwh(disp['Q_solar_direct_W'])
    e_tes    = _safe_mwh(disp['Q_tes_W'])
    e_hp     = _safe_mwh(disp['Q_hp_W'])
    e_elh    = _safe_mwh(disp['Q_elheater_W'])
    e_unmet  = _safe_mwh(disp['Q_unmet_W'])

    e_pv_total  = _safe_mwh(disp['P_pv_ac_W'])
    e_export    = _safe_mwh(disp['P_grid_export_W'])
    e_bess_in   = _safe_mwh(disp['P_bess_charge_W'])
    e_bess_out  = _safe_mwh(disp['P_bess_discharge_W'])
    e_bess_loss = max(e_bess_in - e_bess_out, 0.0)
    e_pv_direct = max(e_pv_total - e_bess_in - e_export, 0.0)
    e_grid      = _safe_mwh(disp['P_grid_import_W'])
    e_hp_el     = _safe_mwh(disp['P_hp_elec_W'])
    e_elh_el    = _safe_mwh(disp['P_elheater_elec_W'])

    fig, axes = plt.subplots(1, 2, figsize=(16, 5))

    ax = axes[0]
    ax.set_title('Annual thermal source → sink Sankey')
    Sankey(ax=ax, unit=' MWh/yr', scale=1.0 / max(e_demand, 1e-9), gap=0.55, offset=0.2, head_angle=120, shoulder=0.03).add(
        flows=[e_stc, e_tes, e_hp, e_elh, -e_demand, e_unmet],
        labels=['STC direct', 'TES discharge', 'Heat pump', 'El. heater', 'Process demand served', 'Unmet'],
        orientations=[1, 1, 1, 1, 0, -1],
        trunklength=1.0,
        pathlengths=[0.35, 0.45, 0.55, 0.65, 0.85, 0.45]
    ).finish()
    ax.axis('off')

    ax = axes[1]
    ax.set_title('Annual electrical source → sink Sankey')
    s = Sankey(ax=ax, unit=' MWh/yr', scale=1.0 / max(e_pv_total + e_grid, 1e-9), gap=0.5, offset=0.2, head_angle=120, shoulder=0.03)
    s.add(
        flows=[e_pv_total, -e_pv_direct, -e_bess_in, -e_export],
        labels=['PV AC', 'PV direct to load', 'Charge BESS', 'Grid export'],
        orientations=[0, 1, 1, -1],
        trunklength=1.0,
        pathlengths=[0.4, 0.45, 0.55, 0.45]
    )
    s.add(
        flows=[e_bess_in, -e_bess_out, -e_bess_loss],
        labels=['BESS charged', 'BESS to load', 'BESS losses'],
        orientations=[0, 1, -1],
        prior=0, connect=(2, 0),
        trunklength=0.9,
        pathlengths=[0.3, 0.45, 0.35]
    )
    s.add(
        flows=[e_pv_direct, e_bess_out, e_grid, -e_hp_el, -e_elh_el],
        labels=['PV direct', 'BESS discharge', 'Grid import', 'HP electric', 'EH electric'],
        orientations=[1, 1, 0, -1, -1],
        trunklength=1.0,
        pathlengths=[0.35, 0.45, 0.55, 0.55, 0.65]
    )
    s.finish()
    ax.axis('off')

    plt.tight_layout()


def plot_cost_breakdown(econ):
    capex = econ['capex_breakdown']
    opex = econ['opex_breakdown']
    export_rev = econ['export_revenue_annual']

    cap_labels = list(capex.keys())
    cap_vals = np.array(list(capex.values()), dtype=float)

    op_labels = list(opex.keys())
    op_vals = np.array(list(opex.values()), dtype=float)

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    fig.suptitle('CAPEX and OPEX Breakdown', fontsize=14, fontweight='bold')

    ax = axes[0]
    colors_cap = plt.cm.Set3(np.linspace(0, 1, len(cap_vals)))
    ax.pie(cap_vals, labels=cap_labels, autopct=lambda p: f'{p:.1f}%' if p >= 3 else '',
           startangle=120, colors=colors_cap, wedgeprops=dict(width=0.45, edgecolor='white'))
    ax.set_title(f'CAPEX Breakdown\nTotal = {econ["capex_total"]/1e6:.2f} M€')

    ax = axes[1]
    colors_op = plt.cm.Paired(np.linspace(0, 1, len(op_vals)))
    ax.pie(op_vals, labels=op_labels, autopct=lambda p: f'{p:.1f}%' if p >= 3 else '',
           startangle=100, colors=colors_op, wedgeprops=dict(width=0.45, edgecolor='white'))
    ax.set_title(
        'Annual OPEX Breakdown\n'
        f'Gross OPEX = {np.sum(op_vals)/1e6:.2f} M€/yr'
        f' | Export revenue = {export_rev/1e3:.1f} k€/yr'
    )

    plt.tight_layout()


def plot_results(opt_result, Q_demand, climate):
    best = opt_result['best']
    disp = best['dispatch']
    econ = best['econ']
    months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    x = np.arange(12)

    monthly_pct = np.zeros((12, 4))
    for m in range(1, 13):
        idx = climate['month'] == m
        dem = Q_demand[idx].sum()
        if dem > 0:
            monthly_pct[m-1, 0] = disp['Q_solar_direct_W'][idx].sum() / dem * 100.0
            monthly_pct[m-1, 1] = disp['Q_tes_W'][idx].sum() / dem * 100.0
            monthly_pct[m-1, 2] = disp['Q_hp_W'][idx].sum() / dem * 100.0
            monthly_pct[m-1, 3] = disp['Q_elheater_W'][idx].sum() / dem * 100.0

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(x, monthly_pct[:, 0], label='STC direct', color='#F5A623')
    ax.bar(x, monthly_pct[:, 1], bottom=monthly_pct[:, 0], label='TES discharge', color='#E07B54')
    ax.bar(x, monthly_pct[:, 2], bottom=monthly_pct[:, 0] + monthly_pct[:, 1], label='Heat pump', color='#4C72B0')
    ax.bar(x, monthly_pct[:, 3], bottom=monthly_pct[:, 0] + monthly_pct[:, 1] + monthly_pct[:, 2], label='El. heater', color='#55A868')
    ax.set_xticks(x); ax.set_xticklabels(months)
    ax.set_ylabel('Demand coverage  [%]')
    ax.set_title('Monthly thermal demand coverage by subsystem')
    ax.legend(loc='upper right'); ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()

    idx_week = np.where(climate['month'] == P.PLOT_WEEK_MONTH)[0][:168]
    fig, ax = plt.subplots(figsize=(12, 5))
    pct_stc = _percent(disp['Q_solar_direct_W'][idx_week], Q_demand[idx_week])
    pct_tes = _percent(disp['Q_tes_W'][idx_week], Q_demand[idx_week])
    pct_hp  = _percent(disp['Q_hp_W'][idx_week], Q_demand[idx_week])
    pct_elh = _percent(disp['Q_elheater_W'][idx_week], Q_demand[idx_week])
    ax.stackplot(range(len(idx_week)), pct_stc, pct_tes, pct_hp, pct_elh,
                 labels=['STC direct','TES','Heat pump','El. heater'],
                 colors=['#F5A623','#E07B54','#4C72B0','#55A868'])
    ax.set_ylabel('Demand coverage  [%]')
    ax.set_xlabel('Hour of week')
    ax.set_title(f'Typical week thermal coverage (month {P.PLOT_WEEK_MONTH})')
    ax.set_ylim(0, 110)
    ax.legend(loc='upper right')
    ax.grid(alpha=0.3)
    plt.tight_layout()

    plot_typical_week_power(disp, Q_demand, climate)

    monthly_elec = np.zeros((12, 3))
    for m in range(1, 13):
        idx = climate['month'] == m
        el_dem = (disp['P_hp_elec_W'][idx].sum() + disp['P_elheater_elec_W'][idx].sum())
        if el_dem > 0:
            local = (disp['P_hp_from_local_W'][idx].sum() + disp['P_elheater_from_local_W'][idx].sum())
            bess = disp['P_bess_discharge_W'][idx].sum()
            grid = disp['P_grid_import_W'][idx].sum()
            monthly_elec[m-1, 0] = max(local - bess, 0.0) / el_dem * 100.0
            monthly_elec[m-1, 1] = bess / el_dem * 100.0
            monthly_elec[m-1, 2] = grid / el_dem * 100.0

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(x, monthly_elec[:, 0], label='PV direct', color='#F5A623')
    ax.bar(x, monthly_elec[:, 1], bottom=monthly_elec[:, 0], label='BESS discharge', color='#4C72B0')
    ax.bar(x, monthly_elec[:, 2], bottom=monthly_elec[:, 0] + monthly_elec[:, 1], label='Grid import', color='#C44E52')
    ax.set_xticks(x); ax.set_xticklabels(months)
    ax.set_ylabel('Electric supply share  [%]')
    ax.set_title('Monthly electric supply split for HP + electric heater')
    ax.legend(); ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()

    monthly_cop = np.zeros(12)
    for m in range(1, 13):
        idx = climate['month'] == m
        q_hp = disp['Q_hp_W'][idx]
        cop_h = disp['COP_hourly'][idx]
        total = q_hp.sum()
        monthly_cop[m-1] = float((cop_h * q_hp).sum() / total) if total > 0 else 0.0

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    ax = axes[0]
    ax.bar(x, monthly_cop, color='#4C72B0', alpha=0.85)
    ax.axhline(econ['COP_weighted'], color='red', linestyle='--', linewidth=1.5,
               label=f'Annual avg COP = {econ["COP_weighted"]:.2f}')
    ax.set_xticks(x); ax.set_xticklabels(months)
    ax.set_ylabel('Weighted avg COP  [-]')
    ax.set_title('Monthly heat-pump COP profile\n(variable: ambient vs waste-heat source)')
    ax.legend(); ax.grid(axis='y', alpha=0.3)
    ax.set_ylim(0, max(monthly_cop) * 1.25 if np.max(monthly_cop) > 0 else 1.0)

    ax2 = axes[1]
    capex_vals = [econ['capex_stc'], econ['capex_tes'], econ['capex_hp'], econ['capex_elheater'], econ['capex_pv'], econ['capex_bess'], econ['capex_inv']]
    capex_labels = ['STC', 'TES', 'HP', 'El. heater', 'PV', 'BESS', 'Inverter']
    colors = ['#F5A623','#E07B54','#4C72B0','#55A868','#FDD92A','#8172B2','#C44E52']
    ax2.pie(capex_vals, labels=capex_labels, colors=colors,
            autopct=lambda p: f'{p:.1f}%' if p > 3 else '', startangle=140, pctdistance=0.82)
    ax2.set_title(f'CAPEX breakdown\n(Total: {econ["capex_total"]/1e6:.1f} M€)')
    plt.tight_layout()

    plot_source_sink_sankey(disp, Q_demand)
    plt.show()


def plot_scenario_comparison(scenario_results):
    temps = sorted(scenario_results.keys())
    lcoh_v = [scenario_results[T]['econ']['LCOH'] for T in temps]
    sf_v   = [scenario_results[T]['econ']['solar_fraction'] for T in temps]
    co2_v  = [scenario_results[T]['econ']['co2_avoided_tonne_yr'] for T in temps]
    hp_ok  = [scenario_results[T]['hp_ok'] for T in temps]

    labels = [f'{T} °C\n(HP {"ON" if ok else "OFF"})' for T, ok in zip(temps, hp_ok)]
    x = np.arange(len(temps))

    fig, axes = plt.subplots(1, 3, figsize=(14, 5))
    fig.suptitle('T_SUPPLY Scenario Comparison — Same Optimal Sizing', fontsize=12, fontweight='bold')

    for ax, vals, title, col in zip(
        axes,
        [lcoh_v, sf_v, co2_v],
        ['LCOH  [€/MWh_th]', 'Solar Fraction  [%]', 'CO₂ avoided  [t/yr]'],
        ['#4C72B0', '#F5A623', '#55A868']
    ):
        bars = ax.bar(x, vals, color=col, alpha=0.85, width=0.55)
        ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=9)
        ax.set_title(title)
        ax.grid(axis='y', alpha=0.3)
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + max(vals) * 0.02,
                    f'{v:.1f}', ha='center', va='bottom', fontsize=9)

    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    print('=' * 68)
    print('  Hybrid Solar Process-Heat System — Integrated Simulation')
    print('=' * 68)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(base_dir, 'seville_tmy.csv')
    climate  = climate_data.load_climate_data(csv_path)

    Q_demand = build_demand(climate)
    print('[Demand] Annual thermal demand: {0:.1f} MWh  ({1}–{2}h shift, {3:.0f} MW load)'.format(
        Q_demand.sum() / 1e6, P.HOUR_START, P.HOUR_END, P.LOAD_W / 1e6))
    print('[Params] T_supply = {0} °C | T_return = {1} °C'.format(P.T_SUPPLY, P.T_RETURN))
    print('[Params] HP eta_Carnot = {0:.2f} | HP_T_MAX = {1} °C'.format(P.HP_ETA_CARNOT, P.HP_T_MAX))

    print('\n[Optimiser] Running base-case optimisation ...')
    opt_result = optimiser.run(climate, Q_demand)
    best = opt_result['best']

    economics.print_summary(best['econ'], best['dispatch'],
                            label=f"BASE CASE — T_supply = {P.T_SUPPLY} °C")

    print('\n' + '─' * 68)
    print('  T_SUPPLY SCENARIO ANALYSIS  (fixed optimal sizing, varying temperature)')
    print('─' * 68)
    scenario_results = run_temperature_scenarios(best, climate, Q_demand)

    print('\n[Sensitivity] Running OAT sensitivity analysis ...')
    sens_results = sensitivity.run(best, Q_demand)
    sensitivity.print_table(sens_results)

    plot_results(opt_result, Q_demand, climate)
    plot_cost_breakdown(best['econ'])
    plot_scenario_comparison(scenario_results)
    sensitivity.plot_tornado(sens_results)
    plt.show()
