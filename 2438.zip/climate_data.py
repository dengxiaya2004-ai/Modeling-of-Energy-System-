# climate_data.py
# Unified PVGIS TMY loader for thermal and electrical subsystems.

import os
import numpy as np
import pandas as pd


def _build_month_hour_vectors(n_hours=8760):
    days_per_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    month = np.zeros(n_hours, dtype=int)
    hour_of_day = np.zeros(n_hours, dtype=int)
    idx = 0
    for m, days in enumerate(days_per_month, start=1):
        for _ in range(days):
            for h in range(24):
                if idx >= n_hours:
                    break
                month[idx] = m
                hour_of_day[idx] = h
                idx += 1
    return month, hour_of_day


def load_climate_data(filepath):
    if not os.path.isfile(filepath):
        raise FileNotFoundError(
            "File not found: {0}\nExpected a PVGIS TMY CSV such as 'seville_tmy.csv'.".format(filepath)
        )

    header_row = None
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        for i, line in enumerate(f):
            if 'time(UTC)' in line or 'time(UTC),' in line:
                header_row = i
                break
    if header_row is None:
        raise ValueError("Could not find PVGIS header row containing 'time(UTC)'.")

    df = pd.read_csv(filepath, skiprows=header_row, nrows=8760)
    df.columns = [c.strip() for c in df.columns]

    required = ['Gb(n)', 'T2m']
    for col in required:
        if col not in df.columns:
            raise ValueError("Missing required PVGIS column: {0}".format(col))

    ghi_col = 'G(h)' if 'G(h)' in df.columns else 'Gd(h)'
    dhi_col = 'Gd(h)' if 'Gd(h)' in df.columns else None
    ws_col = 'WS10m' if 'WS10m' in df.columns else None
    sp_col = 'SP' if 'SP' in df.columns else None

    dni = np.maximum(df['Gb(n)'].values.astype(float), 0.0)
    ghi = np.maximum(df[ghi_col].values.astype(float), 0.0)
    dhi = np.maximum(df[dhi_col].values.astype(float), 0.0) if dhi_col else 0.15 * ghi
    tamb = df['T2m'].values.astype(float)
    wind = df[ws_col].values.astype(float) if ws_col else np.full(8760, 1.0)
    pressure = df[sp_col].values.astype(float) if sp_col else np.full(8760, 101325.0)

    month, hour_of_day = _build_month_hour_vectors(8760)

    climate = {
        'DNI': dni,
        'GHI': ghi,
        'DHI': dhi,
        'T_amb': tamb,
        'wind_speed': wind,
        'pressure': pressure,
        'month': month,
        'hour_of_day': hour_of_day,
        'n_hours': 8760,
    }

    print("[Climate] Annual average DNI:         {0:.1f} W/m²".format(dni.mean()))
    print("[Climate] Annual average GHI:         {0:.1f} W/m²".format(ghi.mean()))
    print("[Climate] Annual average temperature: {0:.1f} °C".format(tamb.mean()))
    print("[Climate] Sun hours (DNI > 50):       {0} h/year".format(int((dni > 50).sum())))
    return climate
