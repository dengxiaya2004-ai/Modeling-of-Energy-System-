# params.py
# Integrated whole-plant parameter file

# ── Process ────────────────────────────────────────────────────────────────
LOAD_W         = 10e6       # Thermal load during shift [W]
T_SUPPLY       = 100        # Process supply temperature [°C]
T_RETURN       = 50         # Process return temperature [°C]
HOUR_START     = 8          # Shift start hour (inclusive)
HOUR_END       = 18         # Shift end hour (exclusive)
LATITUDE       = 37.4       # Site latitude [°N] — Seville

# T_SUPPLY scenario list (°C) — used in main.py for scenario comparison.
# At 180 °C the HP is above its T_MAX and is automatically disabled.
T_SUPPLY_SCENARIOS = [100, 150, 180]

# ── STC — Absolicon T160 ───────────────────────────────────────────────────
ETA0           = 0.762      # Peak optical efficiency [-]
A1             = 0.665      # 1st-order heat loss coefficient [W/(m²·K)]
A2             = 0.00378    # 2nd-order heat loss coefficient [W/(m²·K²)]
APERTURE_W     = 1.7        # Aperture width [m]
MODULE_L       = 12.0       # Module length [m]
A_MODULE       = APERTURE_W * MODULE_L   # Aperture area per module [m²]
DNI_MIN        = 50         # Minimum DNI to operate [W/m²]
IAM_B0         = 0.10       # IAM incidence angle coefficient [-]

# ── TES — pressurised hot-water tank ──────────────────────────────────────
CP_WATER       = 4186       # Specific heat of water [J/(kg·K)]
RHO_WATER      = 975        # Density of water at ~80 °C [kg/m³]
T_TES_MAX      = 105        # Max tank temperature [°C]
T_TES_MIN      = 55         # Min useful tank temperature [°C]
DELTA_T_TES    = T_TES_MAX - T_TES_MIN   # Usable ΔT [K]
TES_LOSS_FRAC  = 0.003      # Fractional hourly standing loss [-]
SOC_MAX        = 1.00
SOC_MIN        = 0.05
SOC_INITIAL    = 0.50
TES_MAX_DISCHARGE_FRAC = 0.50   # Max HX throughput per hour [fraction of E_tes]

# ── Waste heat ─────────────────────────────────────────────────────────────
T_WASTE_HEAT   = 70.0       # Waste heat source temperature [°C]
Q_WASTE_MAX_W  = 5e6        # Max available waste heat power [W]

# ── Heat pump — variable COP (Carnot-based) ────────────────────────────────
# COP(T_source, T_sink) = HP_ETA_CARNOT × T_sink_K / (T_sink_K − T_source_K)
# Waste heat (70 °C) is used as source during shift hours when available;
# ambient air is the fallback source outside shift hours.
HP_ETA_CARNOT      = 0.45   # Second-law (isentropic) efficiency of HP cycle [-]
HP_COP_MIN         = 1.1    # Minimum realistic COP — safety clip [-]
HP_COP_MAX         = 8.0    # Maximum realistic COP — safety clip [-]
HP_T_MAX           = 157.0  # Maximum HP delivery temperature [°C]
HP_CAPACITY_KW     = 4000.0 # Rated thermal capacity [kW]

# ── Electric heater + grid ─────────────────────────────────────────────────
EL_HEATER_EFF          = 0.99
EL_HEATER_CAPACITY_KW  = 10000.0
GRID_IMPORT_MAX_KW     = 12000.0

# ── PV + inverter ──────────────────────────────────────────────────────────
PV_ETA               = 0.20    # Module STC efficiency [-]
PV_AREA_MODULE       = 2.0     # Module area [m²]
PV_TEMP_COEFF        = -0.004  # Power temperature coefficient [1/K]
PV_NOCT_C            = 45.0   # NOCT [°C]
PV_PERFORMANCE_RATIO = 0.90    # System PR (wiring, soiling, mismatch) [-]
PV_INV_EFF           = 0.97   # Inverter efficiency [-]
PV_PEAK_PER_MODULE_KW = PV_AREA_MODULE * PV_ETA   # [kWp/module]

# ── BESS ───────────────────────────────────────────────────────────────────
BESS_ETA_CHARGE    = 0.95
BESS_ETA_DISCHARGE = 0.95
BESS_LOSS_FRAC     = 0.001   # Hourly self-discharge [-]
BESS_SOC_MAX       = 0.95
BESS_SOC_MIN       = 0.10
BESS_SOC_INITIAL   = 0.50
BESS_MAX_C_RATE    = 0.50    # Max charge/discharge rate [C]

# ── Electricity prices ─────────────────────────────────────────────────────
ELEC_PRICE         = 0.12    # Grid buy price  [€/kWh]
ELEC_EXPORT_PRICE  = 0.05    # Grid sell price [€/kWh]

# ── Reference scenario — natural gas boiler ────────────────────────────────
GAS_PRICE_EUR_KWH  = 0.045   # Gas price (HHV basis) [€/kWh_gas]
BOILER_EFFICIENCY  = 0.90    # Reference boiler efficiency [-]

# ── CO₂ emission factors ───────────────────────────────────────────────────
CO2_GRID_KG_KWH    = 0.20    # Grid electricity emission factor [kg CO₂/kWh_el]
                              # (Spain average, REE 2023)
CO2_GAS_KG_KWH     = 0.202   # Natural gas combustion factor   [kg CO₂/kWh_gas]

# ── Financial parameters ───────────────────────────────────────────────────
DISCOUNT_RATE  = 0.06
LIFETIME_YR    = 25

# ── CAPEX [€] ──────────────────────────────────────────────────────────────
CAPEX_STC_PER_M2    = 380    # €/m² aperture
CAPEX_TES_PER_KWH   = 40     # €/kWh_th stored
CAPEX_HP_PER_KW     = 500    # €/kW_th rated
CAPEX_EL_HEATER_KW  = 80     # €/kW_th rated
CAPEX_PV_PER_KWP    = 700    # €/kWp
CAPEX_BESS_PER_KWH  = 350    # €/kWh stored
CAPEX_INV_PER_KW    = 45     # €/kW_ac

# ── O&M (fraction of CAPEX per year) ──────────────────────────────────────
OM_STC_FRAC    = 0.015
OM_TES_FRAC    = 0.010
OM_HP_FRAC     = 0.025
OM_EL_FRAC     = 0.015
OM_PV_FRAC     = 0.010
OM_BESS_FRAC   = 0.020
OM_INV_FRAC    = 0.010

# ── Optimiser search space ─────────────────────────────────────────────────
OPT_N_STC_RANGE     = range(300, 1400, 100)
OPT_E_TES_RANGE     = range(20, 181, 20)       # MWh
OPT_N_PV_RANGE      = range(2000, 10001, 1000)
OPT_E_BESS_RANGE    = range(2, 21, 2)          # MWh

# ── Participation constraints (Scheme A) ───────────────────────────────────
MIN_STC_SHARE       = 0.03
MIN_TES_SHARE       = 0.03
MIN_HP_SHARE        = 0.05
MIN_ELH_SHARE       = 0.01
MIN_PV_ELEC_SHARE   = 0.03
MIN_BESS_ELEC_SHARE = 0.02

# ── Plotting ───────────────────────────────────────────────────────────────
PLOT_WEEK_MONTH = 6    # Month used for "typical week" plot

# ── Sensitivity analysis ───────────────────────────────────────────────────
# Parameter name → fractional variation applied symmetrically (±δ).
# Only economic/financial parameters are varied; physical parameters
# (climate, equipment specs) are not included here.
SENSITIVITY_PARAMS = {
    'ELEC_PRICE':          0.30,   # ±30 %
    'GAS_PRICE_EUR_KWH':   0.25,   # ±25 %
    'DISCOUNT_RATE':       0.50,   # ±50 %  (4 % – 9 %)
    'CAPEX_STC_PER_M2':    0.20,   # ±20 %
    'CAPEX_PV_PER_KWP':    0.20,   # ±20 %
    'CAPEX_BESS_PER_KWH':  0.20,   # ±20 %
    'CAPEX_HP_PER_KW':     0.20,   # ±20 %
}
