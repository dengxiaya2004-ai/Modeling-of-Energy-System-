# hp_model.py
# High-Temperature Heat Pump model — variable COP (Carnot-based)
#
# Change vs original:
#   The COP is no longer a fixed constant (HP_COP = 2.32).
#   It is now computed hourly from the actual source temperature
#   (ambient air or industrial waste heat) and the required sink
#   temperature (process supply temperature T_SUPPLY), following
#   the standard Carnot scaling with a second-law efficiency factor.
#
#   COP(T_src, T_snk) = η_Carnot × T_snk_K / (T_snk_K − T_src_K)
#
#   During shift hours, the dispatcher passes T_WASTE_HEAT as the
#   source temperature, which raises the COP significantly (higher
#   source → smaller temperature lift → less compressor work).

import numpy as np
import params as P


# ─────────────────────────────────────────────────────────────────────────────
# COP computation
# ─────────────────────────────────────────────────────────────────────────────

def compute_cop(T_source_C, T_sink_C, eta_carnot=None):
    """
    Compute the realistic hourly COP of the heat pump.

    Parameters
    ----------
    T_source_C : float or np.ndarray [°C]
        Heat-source temperature each hour.
        During shift hours with waste heat available the dispatcher
        supplies T_WASTE_HEAT (70 °C); otherwise ambient T_amb is used.
    T_sink_C   : float [°C]
        Required process supply temperature (P.T_SUPPLY).
    eta_carnot : float, optional
        Second-law efficiency of the HP cycle (default P.HP_ETA_CARNOT).
        Typical range for industrial HTHPs: 0.40 – 0.50.

    Returns
    -------
    cop : same shape as T_source_C, clipped to [HP_COP_MIN, HP_COP_MAX].

    Physical interpretation
    -----------------------
    A higher source temperature (waste heat 70 °C vs. ambient 15 °C) reduces
    the temperature lift and therefore the compressor work, increasing COP.
    Example at T_sink = 100 °C, η = 0.45:
        T_src = 15 °C  →  COP ≈ 0.45 × 373 / 85  ≈ 1.98
        T_src = 70 °C  →  COP ≈ 0.45 × 373 / 30  ≈ 5.60
    """
    if eta_carnot is None:
        eta_carnot = P.HP_ETA_CARNOT

    T_src_K = np.asarray(T_source_C, dtype=float) + 273.15
    T_snk_K = float(T_sink_C) + 273.15

    # Temperature lift — clamp to ≥ 1 K to avoid division by zero
    delta_T = np.maximum(T_snk_K - T_src_K, 1.0)

    cop_carnot = T_snk_K / delta_T
    cop = eta_carnot * cop_carnot
    return np.clip(cop, P.HP_COP_MIN, P.HP_COP_MAX)


# ─────────────────────────────────────────────────────────────────────────────
# Main simulation
# ─────────────────────────────────────────────────────────────────────────────

def simulate(Q_residual_W, T_source_C, T_sink_C=None, P_hp_kW=None):
    """
    Simulate the heat pump over all 8760 hours.

    Parameters
    ----------
    Q_residual_W : np.ndarray [W]
        Hourly thermal demand not satisfied by STC + TES.
    T_source_C   : float or np.ndarray [°C]
        Hourly heat-source temperature.  The dispatcher passes
        T_WASTE_HEAT during shift hours (when waste heat is available)
        and T_amb otherwise.
    T_sink_C     : float [°C], optional
        Process supply temperature (default P.T_SUPPLY).
    P_hp_kW      : float [kW], optional
        Rated thermal capacity (default P.HP_CAPACITY_KW).

    Returns
    -------
    dict
        Q_hp_W        : heat delivered by the HP [W]
        P_hp_elec_W   : electrical power consumed [W]
        Q_residual_W  : remaining unmet demand after HP [W]
        COP_hourly    : hourly COP array [-]
        P_hp_kW       : rated capacity used [kW]
        hp_enabled    : bool — False if T_sink > HP_T_MAX

    Notes
    -----
    If the required sink temperature exceeds the HP's rated maximum
    (P.HP_T_MAX), the HP is fully bypassed and the entire residual
    demand is passed to the electric heater.  This happens automatically
    for the T_SUPPLY = 180 °C scenario.
    """
    if T_sink_C is None:
        T_sink_C = P.T_SUPPLY
    if P_hp_kW is None:
        P_hp_kW = P.HP_CAPACITY_KW

    n = len(np.asarray(Q_residual_W))

    # ── HP temperature feasibility check ─────────────────────────────────
    if T_sink_C > P.HP_T_MAX:
        # HP cannot deliver heat at this temperature — bypass entirely
        return {
            'Q_hp_W':       np.zeros(n),
            'P_hp_elec_W':  np.zeros(n),
            'Q_residual_W': np.maximum(Q_residual_W, 0.0),
            'COP_hourly':   np.zeros(n),
            'P_hp_kW':      P_hp_kW,
            'hp_enabled':   False,
        }

    # ── Variable-COP calculation ──────────────────────────────────────────
    cop = compute_cop(T_source_C, T_sink_C)   # shape (n,) or scalar

    # ── Thermal output ────────────────────────────────────────────────────
    q_max    = P_hp_kW * 1000.0                               # [W]
    q_hp     = np.minimum(np.maximum(Q_residual_W, 0.0), q_max)
    p_hp_elec = q_hp / cop                                    # [W_el]
    q_after  = np.maximum(Q_residual_W - q_hp, 0.0)

    return {
        'Q_hp_W':       q_hp,
        'P_hp_elec_W':  p_hp_elec,
        'Q_residual_W': q_after,
        'COP_hourly':   np.broadcast_to(cop, q_hp.shape).copy(),
        'P_hp_kW':      P_hp_kW,
        'hp_enabled':   True,
    }
