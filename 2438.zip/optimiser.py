
"""
Pure-Python optimiser for the hybrid solar process-heat system.

This version removes the Pyomo dependency and performs the same
simulation-based enumeration directly in Python.

Problem
-------
    min   LCOH(n_stc, E_tes, n_pv, E_bess)          [€/MWh_th]
    s.t.  stc_share        >= MIN_STC_SHARE
          tes_share        >= MIN_TES_SHARE
          hp_share         >= MIN_HP_SHARE
          elh_share        >= MIN_ELH_SHARE
          pv_elec_share    >= MIN_PV_ELEC_SHARE
          bess_elec_share  >= MIN_BESS_ELEC_SHARE
          n_stc  ∈ OPT_N_STC_RANGE   (integer)
          E_tes  ∈ OPT_E_TES_RANGE   [MWh] (discrete)
          n_pv   ∈ OPT_N_PV_RANGE    (integer)
          E_bess ∈ OPT_E_BESS_RANGE  [MWh] (discrete)
"""

import itertools
import numpy as np

import params as P
import dispatcher
import economics


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _simulate(n_stc, E_tes_MWh, n_pv, E_bess_MWh, climate, Q_demand_W):
    """Run dispatch + economics for one candidate design point."""
    disp = dispatcher.run(
        climate, Q_demand_W,
        int(n_stc),
        float(E_tes_MWh) * 1e6,
        int(n_pv),
        float(E_bess_MWh) * 1e6,
    )
    econ = economics.compute(disp, Q_demand_W)
    return disp, econ


def _check_constraints(part):
    """
    Return (is_feasible, violations_dict) based on participation constraints.
    """
    checks = {
        'stc_share':      (part['stc_share'],      P.MIN_STC_SHARE),
        'tes_share':      (part['tes_share'],      P.MIN_TES_SHARE),
        'hp_share':       (part['hp_share'],       P.MIN_HP_SHARE),
        'elh_share':      (part['elh_share'],      P.MIN_ELH_SHARE),
        'pv_elec_share':  (part['pv_elec_share'],  P.MIN_PV_ELEC_SHARE),
        'bess_elec_share':(part['bess_elec_share'],P.MIN_BESS_ELEC_SHARE),
    }

    violations = {}
    tol = 1e-8
    feasible = True
    for name, (value, lower_bound) in checks.items():
        if value < lower_bound - tol:
            feasible = False
            violations[name] = {
                'value': float(value),
                'required_min': float(lower_bound),
                'gap': float(lower_bound - value),
            }
    return feasible, violations


def _iter_values(spec):
    """
    Accept either:
      - Python range
      - list / tuple / np.ndarray of explicit values
    and return an iterable list.
    """
    if isinstance(spec, range):
        return list(spec)
    if isinstance(spec, np.ndarray):
        return spec.tolist()
    if isinstance(spec, (list, tuple)):
        return list(spec)
    raise TypeError(f"Unsupported optimisation range type: {type(spec)!r}")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run(climate, Q_demand_W):
    """
    Solve the LCOH minimisation problem by brute-force enumeration.

    Parameters
    ----------
    climate     : dict
        From climate_data.load_climate_data()
    Q_demand_W  : np.ndarray [W]
        Hourly thermal demand

    Returns
    -------
    dict with keys:
        'best'               : best feasible design record
        'n_evaluated'        : total number of candidate points evaluated
        'n_feasible'         : number of feasible candidate points
        'records'            : all candidate records
        'best_feasible_lcoh' : best feasible LCOH
    """
    n_stc_values   = _iter_values(P.OPT_N_STC_RANGE)
    e_tes_values   = _iter_values(P.OPT_E_TES_RANGE)
    n_pv_values    = _iter_values(P.OPT_N_PV_RANGE)
    e_bess_values  = _iter_values(P.OPT_E_BESS_RANGE)

    total_candidates = (
        len(n_stc_values) *
        len(e_tes_values) *
        len(n_pv_values) *
        len(e_bess_values)
    )

    print("[Optimiser] Pure-Python enumeration started")
    print(f"[Optimiser] Candidate grid size: {total_candidates:,}")

    records = []
    best = None
    best_feasible_lcoh = float('inf')
    n_feasible = 0
    n_evaluated = 0

    for n_stc, E_tes_MWh, n_pv, E_bess_MWh in itertools.product(
        n_stc_values, e_tes_values, n_pv_values, e_bess_values
    ):
        n_evaluated += 1

        disp, econ = _simulate(
            n_stc=n_stc,
            E_tes_MWh=E_tes_MWh,
            n_pv=n_pv,
            E_bess_MWh=E_bess_MWh,
            climate=climate,
            Q_demand_W=Q_demand_W,
        )

        feasible, violations = _check_constraints(disp['participation'])

        record = {
            'n_stc': int(n_stc),
            'E_tes_MWh': float(E_tes_MWh),
            'E_tes_Wh': float(E_tes_MWh) * 1e6,
            'n_pv': int(n_pv),
            'E_bess_MWh': float(E_bess_MWh),
            'E_bess_Wh': float(E_bess_MWh) * 1e6,
            'dispatch': disp,
            'econ': econ,
            'feasible': feasible,
            'violations': violations,
            'LCOH': float(econ['LCOH']),
        }
        records.append(record)

        if feasible:
            n_feasible += 1
            if econ['LCOH'] < best_feasible_lcoh:
                best_feasible_lcoh = float(econ['LCOH'])
                best = record

    print(f"[Optimiser] Evaluated candidates: {n_evaluated:,}")
    print(f"[Optimiser] Feasible candidates:  {n_feasible:,}")

    if best is None:
        raise RuntimeError(
            "No feasible design found in the optimisation grid. "
            "Try relaxing participation-share constraints or widening search ranges."
        )

    print(
        "[Optimiser] Best feasible design: "
        f"n_stc={best['n_stc']}, "
        f"E_tes={best['E_tes_MWh']:.3f} MWh_th, "
        f"n_pv={best['n_pv']}, "
        f"E_bess={best['E_bess_MWh']:.3f} MWh_el, "
        f"LCOH={best['LCOH']:.2f} €/MWh_th"
    )

    return {
        'best': best,
        'n_evaluated': n_evaluated,
        'n_feasible': n_feasible,
        'records': records,
        'best_feasible_lcoh': best_feasible_lcoh,
    }
