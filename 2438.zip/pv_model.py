# pv_model.py

import numpy as np
import params as P


def simulate(climate, n_pv, inverter_efficiency=None):
    if inverter_efficiency is None:
        inverter_efficiency = P.PV_INV_EFF

    ghi = climate['GHI']
    temp = climate['T_amb']
    area_total = n_pv * P.PV_AREA_MODULE
    p_rated_kw = n_pv * P.PV_PEAK_PER_MODULE_KW

    # Simple temperature-corrected PV model
    t_cell = temp + (P.PV_NOCT_C - 20.0) / 800.0 * ghi
    temp_factor = 1.0 + P.PV_TEMP_COEFF * (t_cell - 25.0)
    temp_factor = np.clip(temp_factor, 0.0, 1.2)

    p_dc_w = area_total * P.PV_ETA * ghi * P.PV_PERFORMANCE_RATIO * temp_factor
    p_ac_w = p_dc_w * inverter_efficiency

    return {
        'P_pv_dc_W': p_dc_w,
        'P_pv_ac_W': p_ac_w,
        'A_pv_m2': area_total,
        'P_pv_rated_kW': p_rated_kw,
        'n_pv': n_pv,
    }
