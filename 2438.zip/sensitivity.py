# sensitivity.py
"""
One-At-a-Time (OAT) sensitivity analysis for the optimal design.

Methodology
-----------
For each parameter listed in P.SENSITIVITY_PARAMS, the parameter is
varied ±δ around its base value (e.g. ±20 %).  At each variation the
economics are recomputed for the *fixed optimal design* (no re-dispatch,
no re-optimisation), isolating the sensitivity of LCOH and NPV to
each individual assumption.

The output is:
  1. A formatted table printed to stdout.
  2. A tornado chart (matplotlib figure) showing LCOH swing per parameter.

Note: physical parameters (climate DNI, equipment specs, COP curve)
are not included here because varying them would require re-running the
full simulation.  Only financial/cost parameters are analysed.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import params as P
import economics


# ─────────────────────────────────────────────────────────────────────────────
# Labels for display
# ─────────────────────────────────────────────────────────────────────────────

_LABELS = {
    'ELEC_PRICE':          'Electricity price  [€/kWh]',
    'GAS_PRICE_EUR_KWH':   'Gas price ref.     [€/kWh]',
    'DISCOUNT_RATE':       'Discount rate      [%]',
    'CAPEX_STC_PER_M2':    'CAPEX STC          [€/m²]',
    'CAPEX_PV_PER_KWP':    'CAPEX PV           [€/kWp]',
    'CAPEX_BESS_PER_KWH':  'CAPEX BESS         [€/kWh]',
    'CAPEX_HP_PER_KW':     'CAPEX HP           [€/kW]',
}


# ─────────────────────────────────────────────────────────────────────────────
# Core analysis
# ─────────────────────────────────────────────────────────────────────────────

def run(best_record, Q_demand_W):
    """
    Run OAT sensitivity analysis around the optimal design.

    Parameters
    ----------
    best_record : dict — best record from optimiser.run()['best']
    Q_demand_W  : np.ndarray [W] — hourly thermal demand

    Returns
    -------
    results : dict
        {param_name: {'delta': δ, 'base': base_LCOH,
                      'low_lcoh': ..., 'high_lcoh': ...,
                      'low_npv': ..., 'high_npv': ...,
                      'swing_lcoh': high − low}}
    """
    disp      = best_record['dispatch']
    base_econ = best_record['econ']

    results = {}

    for param, delta in P.SENSITIVITY_PARAMS.items():
        base_val = getattr(P, param)

        # ── Low scenario ───────────────────────────────────────────────
        setattr(P, param, base_val * (1.0 - delta))
        _refresh_crf_if_needed(param)
        econ_low = economics.compute(disp, Q_demand_W)

        # ── High scenario ──────────────────────────────────────────────
        setattr(P, param, base_val * (1.0 + delta))
        _refresh_crf_if_needed(param)
        econ_high = economics.compute(disp, Q_demand_W)

        # ── Restore ────────────────────────────────────────────────────
        setattr(P, param, base_val)
        _refresh_crf_if_needed(param)

        results[param] = {
            'delta':      delta,
            'base_lcoh':  base_econ['LCOH'],
            'low_lcoh':   econ_low['LCOH'],
            'high_lcoh':  econ_high['LCOH'],
            'base_npv':   base_econ['NPV'],
            'low_npv':    econ_low['NPV'],
            'high_npv':   econ_high['NPV'],
            'swing_lcoh': econ_high['LCOH'] - econ_low['LCOH'],
            'swing_npv':  econ_high['NPV']  - econ_low['NPV'],
        }

    return results


def _refresh_crf_if_needed(param):
    """Recompute module-level CRF if discount rate was changed."""
    if param == 'DISCOUNT_RATE':
        economics.CRF = economics.capital_recovery_factor()


# ─────────────────────────────────────────────────────────────────────────────
# Printed table
# ─────────────────────────────────────────────────────────────────────────────

def print_table(results):
    """Print formatted OAT sensitivity table for LCOH and NPV."""
    W = 76
    print("\n" + "=" * W)
    print("  SENSITIVITY ANALYSIS — One-At-a-Time (OAT)")
    print("=" * W)
    print("  {:<32} {:>5}  {:>10}  {:>10}  {:>10}  {:>8}".format(
        "Parameter", "±Δ%", "LCOH low", "LCOH base", "LCOH high", "Swing"))
    print("  {:<32} {:>5}  {:>10}  {:>10}  {:>10}  {:>8}".format(
        "", "", "€/MWh", "€/MWh", "€/MWh", "€/MWh"))
    print("  " + "-" * (W - 2))

    # Sort by absolute LCOH swing
    for param, v in sorted(results.items(),
                            key=lambda x: abs(x[1]['swing_lcoh']), reverse=True):
        label = _LABELS.get(param, param)
        print("  {:<32} {:>4.0f}%  {:>10.2f}  {:>10.2f}  {:>10.2f}  {:>8.2f}".format(
            label,
            v['delta'] * 100,
            v['low_lcoh'], v['base_lcoh'], v['high_lcoh'],
            abs(v['swing_lcoh'])
        ))

    print()
    print("  {:<32} {:>5}  {:>14}  {:>14}  {:>10}".format(
        "Parameter", "±Δ%", "NPV low  [k€]", "NPV high [k€]", "Swing [k€]"))
    print("  " + "-" * (W - 2))
    for param, v in sorted(results.items(),
                            key=lambda x: abs(x[1]['swing_npv']), reverse=True):
        label = _LABELS.get(param, param)
        print("  {:<32} {:>4.0f}%  {:>14,.0f}  {:>14,.0f}  {:>10,.0f}".format(
            label,
            v['delta'] * 100,
            v['low_npv'] / 1000, v['high_npv'] / 1000,
            abs(v['swing_npv']) / 1000
        ))
    print("=" * W + "\n")


# ─────────────────────────────────────────────────────────────────────────────
# Tornado chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_tornado(results):
    """
    Produce a tornado chart showing LCOH sensitivity to each parameter.

    Blue bars = effect of the LOW scenario (−δ %).
    Orange bars = effect of the HIGH scenario (+δ %).
    The base LCOH is shown as a vertical dashed line.
    """
    # Sort by swing magnitude (widest bar at top)
    items = sorted(results.items(),
                   key=lambda x: abs(x[1]['swing_lcoh']), reverse=True)

    labels    = [_LABELS.get(k, k) for k, _ in items]
    low_vals  = [v['low_lcoh']  for _, v in items]
    high_vals = [v['high_lcoh'] for _, v in items]
    base_lcoh = items[0][1]['base_lcoh']
    deltas    = [v['delta']     for _, v in items]

    n = len(labels)
    y = np.arange(n)

    fig, ax = plt.subplots(figsize=(11, max(4, n * 0.85)))
    fig.patch.set_facecolor('#F9F9F9')
    ax.set_facecolor('#F9F9F9')

    COL_POS = '#E07B54'   # orange — parameter increase raises LCOH
    COL_NEG = '#4C72B0'   # blue   — parameter decrease raises LCOH

    for i, (lo, hi, d) in enumerate(zip(low_vals, high_vals, deltas)):
        # Determine which direction is "bad" (higher LCOH)
        if hi >= lo:
            # high param → high LCOH  (e.g. CAPEX, electricity price)
            ax.barh(y[i], hi - base_lcoh, left=base_lcoh,
                    color=COL_POS, alpha=0.85, height=0.55)
            ax.barh(y[i], lo - base_lcoh, left=base_lcoh,
                    color=COL_NEG, alpha=0.85, height=0.55)
            ax.text(hi + 0.15, y[i], f'+{d*100:.0f}%',
                    va='center', fontsize=8, color=COL_POS)
            ax.text(lo - 0.15, y[i], f'−{d*100:.0f}%',
                    va='center', fontsize=8, color=COL_NEG, ha='right')
        else:
            # high param → LOW LCOH  (e.g. gas price: higher gas → better NPV)
            ax.barh(y[i], lo - base_lcoh, left=base_lcoh,
                    color=COL_POS, alpha=0.85, height=0.55)
            ax.barh(y[i], hi - base_lcoh, left=base_lcoh,
                    color=COL_NEG, alpha=0.85, height=0.55)
            ax.text(lo + 0.15, y[i], f'−{d*100:.0f}%',
                    va='center', fontsize=8, color=COL_POS)
            ax.text(hi - 0.15, y[i], f'+{d*100:.0f}%',
                    va='center', fontsize=8, color=COL_NEG, ha='right')

    ax.axvline(base_lcoh, color='black', linewidth=1.8,
               linestyle='--', label=f'Base LCOH = {base_lcoh:.1f} €/MWh_th', zorder=5)

    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel('LCOH  [€/MWh_th]', fontsize=10)
    ax.set_title('Sensitivity Analysis — Tornado Chart (LCOH)', fontsize=12, pad=10)
    ax.legend(fontsize=9)
    ax.grid(axis='x', alpha=0.35, linestyle=':')

    patch_pos = mpatches.Patch(color=COL_POS, alpha=0.85, label='Parameter ↑  (or ↓ if reversed)')
    patch_neg = mpatches.Patch(color=COL_NEG, alpha=0.85, label='Parameter ↓  (or ↑ if reversed)')
    ax.legend(handles=[ax.get_legend_handles_labels()[0][0], patch_pos, patch_neg],
              labels=[f'Base LCOH = {base_lcoh:.1f} €/MWh_th',
                      'CAPEX / price increase', 'CAPEX / price decrease'],
              fontsize=8, loc='lower right')

    plt.tight_layout()
    return fig
